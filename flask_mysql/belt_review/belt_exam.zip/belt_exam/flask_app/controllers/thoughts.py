from flask import render_template, redirect, request, session, flash
from flask_app import app
from flask_app.models.thought import Thought
from flask_app.models.user import User
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)


@app.route('/thoughts')
def thoughts():
    if 'user_id' not in session:
        return redirect('/logout')
    else:
        data={
            "id": session['user_id']
        }
        user= User.get_by_id(data)
        thoughts = Thought.get_all()
        return render_template('dash.html', user=user, thoughts=thoughts)

@app.route('/create/thought', methods=['POST'])
def create_thought():
    if 'user_id' not in session:
        return redirect('/logout')
    if not Thought.validate_thought(request.form):
        return redirect('/thoughts')
    data={
        "description": request.form['description'],
        "user_id": session['user_id']
    }
    Thought.save(data)
    print(data)
    return redirect('/dashboard')

# @app.route('/show/edit/<int:id>')
# def edit(id):
#     if 'user_id' not in session:
#         return redirect('/logout')
#     else:
#         data={
#             "id": session['user_id']
#         }
#         user= User.get_by_id(data)
#     data ={
#         "id": id
#     }
#     return render_template('edit.html', thought=Thought.get_one(data),user=user, thoughts=thoughts)

# @app.route('/show/update', methods=['POST'])
# def update():
#     if not Thought.validate_thought(request.form):
#         update = Thought.get_last()
#         id = update.id
#         return redirect(f'/show/edit/{id}')
#     Thought.update(request.form)
    
#     return redirect('/dashboard')  

# the app below was driving me crazy, but i realized an app.route above was very similar
# and may be better for the job
# @app.route('/show/one/<int:id>')
# def one(id):
#     if 'user_id' not in session:
#         return redirect('/logout')
#     else:
#         data={
#             "id": session['user_id']
#         }
#         user= User.get_by_id(data)
#     data ={
#         "id": id
#     }
#     return render_template('one.html', thoughts=Thought.get_all_thoughts_with_creator(),user=user,)

@app.route('/show/one/<int:id>')
def thought(id):
    if 'user_id' not in session:
        return redirect('/logout')
    else:
        data={
            "id": session['user_id']
        }
    data={
        "id": id
    }
    
    
    return render_template('one.html',thoughts = Thought.get_all(), user= User.get_by_id(data))

    # at this point i didnt really know what to do next, i got very stuck with implementing 
    # different associated classes. Im sure i made some simple mistakes but im just not seeing it at the moment